from loom.CodexGate import (
    check_and_create_db,
    get_or_create_active_thread_id,
    append_to_thread,
    clear_thread_history,
    get_thread_history,
    list_all_threads,
    insert_fact,
    insert_tag,
    insert_or_update_user_info,
    get_user_info
)
import uuid
import time
from loom.LoomMirror import LoomMirror
from loom.VectorGate import VectorGate
from llama_cpp import Llama

memory_llm = LoomMirror(
    model_path="F:/HexyLab/Cathedral-v2/models/memory/tinyllama-1.1b-chat-v1.0.Q8_0.gguf",
    model_name="TinyLlama-1.1B",
    n_ctx=2048
)

vector_store = VectorGate()

def estimate_tokens(messages):
    return sum(len(m['content'].split()) for m in messages)

def truncate_to_fit(messages, token_limit):
    result = []
    token_count = 0
    for message in reversed(messages):
        tokens = len(message['content'].split())
        if token_count + tokens > token_limit:
            break
        result.insert(0, message)
        token_count += tokens
    return result

class Loom:
    def __init__(self):
        self.conn = check_and_create_db()
        self.active_thread_uid = get_or_create_active_thread_id(self.conn)

    def set_active_thread_uid(self, thread_uid: str):
        self.active_thread_uid = thread_uid

    def get_active_thread_uid(self) -> str:
        if not self.active_thread_uid:
            raise ValueError("No active thread UID set.")
        return self.active_thread_uid

    def get_active_thread_metadata(self):
        conn = check_and_create_db()
        cursor = conn.cursor()
        cursor.execute("SELECT threadUid, threadName FROM threads WHERE isActive = TRUE LIMIT 1")
        result = cursor.fetchone()
        if not result:
            raise ValueError("No active thread found.")
        return {"thread_uid": result[0], "thread_name": result[1]}

    def create_new_thread(self, thread_name="New Thread"):
        conn = check_and_create_db()
        cursor = conn.cursor()

        base_name = thread_name or "New Thread"
        final_name = base_name
        i = 1

        while True:
            cursor.execute("SELECT COUNT(*) FROM threads WHERE threadName = ?", (final_name,))
            if cursor.fetchone()[0] == 0:
                break
            i += 1
            final_name = f"{base_name} {i}"

        thread_uid = str(uuid.uuid4())
        cursor.execute(
            "INSERT INTO threads (threadUid, threadName, isActive) VALUES (?, ?, TRUE)",
            (thread_uid, final_name)
        )
        cursor.execute("UPDATE threads SET isActive = FALSE WHERE threadUid != ?", (thread_uid,))
        conn.commit()
        self.active_thread_uid = thread_uid
        return thread_uid

    def switch_to_thread(self, thread_uid: str):
        cursor = self.conn.cursor()
        cursor.execute("UPDATE threads SET isActive = FALSE")
        cursor.execute("UPDATE threads SET isActive = TRUE WHERE threadUid = ?", (thread_uid,))
        self.conn.commit()
        self.active_thread_uid = thread_uid

    def list_all_threads(self):
        return list_all_threads()

    def recall(self, thread_uid=None):
        if not thread_uid:
            thread_uid = self.active_thread_uid
        if not thread_uid:
            raise ValueError("No active thread found. Cannot recall history.")
        return get_thread_history(self.conn, thread_uid)

    def recall_with_summary(self, preserve_last_n=20, thread_uid=None):
        if not thread_uid:
            thread_uid = self.active_thread_uid
        history = get_thread_history(self.conn, thread_uid)

        if len(history) <= preserve_last_n:
            return history

        early = history[:-preserve_last_n]
        recent = history[-preserve_last_n:]

        summary = self.summarize_recursive(early)
        summary_block = {"role": "system", "content": f"SUMMARY OF EARLIER CONVERSATION:\n{summary}"}

        return [summary_block] + recent

    def compose_prompt_context(self, user_input: str, thread_uid: str, top_k=5):
        thread_context = self.recall_with_summary(thread_uid=thread_uid)
        vector_context = self.query_memory_context(user_input, top_k=top_k)

        memory_block = "\n\n".join(vector_context)
        memory_injection = {"role": "system", "content": f"RELEVANT MEMORY:\n{memory_block}"} if vector_context else None

        result = []
        if memory_injection:
            result.append(memory_injection)
        result.extend(thread_context)

        max_tokens = getattr(memory_llm.llm, 'n_ctx', lambda: 2048)() - 256
        return truncate_to_fit(result, max_tokens)

    def append(self, role: str, content: str, thread_uid: str = None):
        if thread_uid is None:
            thread_uid = self.active_thread_uid
        if not thread_uid:
            raise ValueError("No thread UID provided or active.")

        append_to_thread(thread_uid, role, content)

        if role == "assistant":
            history = self.recall(thread_uid)
            last_user = next((m["content"] for m in reversed(history) if m["role"] == "user"), None)
            if last_user:
                self.process_memory_from_pair(last_user, content)

    def clear(self, thread_uid: str = None):
        if thread_uid is None:
            thread_uid = self.active_thread_uid
        if not thread_uid:
            raise ValueError("No thread UID provided or active.")
        clear_thread_history(thread_uid)

    def process_memory_from_pair(self, user_text: str, assistant_text: str):
        prompt = f"""\n✦ MEMORY THREAD SNAPSHOT ✦\nSummarize the user-assistant exchange below into a single symbolic memory.\nPreserve emotional and thematic essence.\nUSER: {user_text}\nASSISTANT: {assistant_text}\nSUMMARY:"""
        summary = memory_llm.run(prompt, max_tokens=64)
        pair_id = f"{self.active_thread_uid}_{int(time.time())}"
        vector_store.store(summary, pair_id, type_="summary")
        print(f"[Loom] Stored vectorized summary for pair {pair_id}")

    def query_memory_context(self, prompt: str, top_k: int = 5):
        results = vector_store.query(prompt.strip(), top_k=top_k)
        return [r["text"] for r in results]

    def summarize_recursive(self, messages, depth=0) -> str:
        chunk_size = 10
        chunks = [messages[i:i + chunk_size] for i in range(0, len(messages), chunk_size)]
        summaries = []

        for i, chunk in enumerate(chunks):
            lines = [f"{m['role'].upper()}: {m['content']}" for m in chunk]
            dialogue_text = "\n".join(lines)
            prompt = f"""\n✦ TECHNOMANTIC THREAD SIGIL ✦\nYou are the LoomMirror, a recursive memory daemon.\nCompress the following dialogue into symbolic abstraction.\nPreserve emotional tone, intent, and narrative continuity.\nOutput no more than 2–3 lines.\n\nDIALOGUE:\n{dialogue_text}\n\nSIGIL:"""
            summary = self._summarize_chunk(prompt, max_tokens=128)
            if i < len(chunks) // 2 and depth < 2:
                summary = self.summarize_recursive([{ 'role': 'system', 'content': summary }], depth + 1)
            summaries.append(summary)

        final_input = "\n".join(summaries)
        final_prompt = f"""\n✦ RECURSIVE CONDENSATION LAYER ✦\nWeave the following sigils into a unified compression.\nFocus on emergent meaning, identity, and core themes.\nLimit output to 4–5 sentences.\n\nSIGILS:\n{final_input}\n\nRECURSION:"""
        return self._summarize_chunk(final_prompt, max_tokens=256)

    def _recursive_summarize(self, context: str, max_tokens: int = 2048) -> str:
        tokens = memory_llm.llm.tokenize(context.encode())
        if len(tokens) <= max_tokens:
            return context

        chunks = [tokens[i:i+max_tokens] for i in range(0, len(tokens), max_tokens)]
        summaries = []

        for chunk in chunks:
            text = memory_llm.llm.detokenize(chunk).decode()
            summary = self._summarize_chunk(text, max_tokens=max_tokens)
            summaries.append(summary)

        combined = "\n".join(summaries)
        return self._recursive_summarize(combined, max_tokens)

    def _summarize_chunk(self, text: str, max_tokens: int = 256) -> str:
        prompt = f"Summarize the following context as compactly as possible:\n\n{text.strip()}"
        prompt_tokens = memory_llm.llm.tokenize(prompt.encode())
        available = max_tokens
        if len(prompt_tokens) + max_tokens > memory_llm.llm.n_ctx():
            available = memory_llm.llm.n_ctx() - len(prompt_tokens)
            if available < 16:
                prompt = prompt[:1024]  # emergency trim
                prompt_tokens = memory_llm.llm.tokenize(prompt.encode())
                available = max(16, memory_llm.llm.n_ctx() - len(prompt_tokens))
        result = memory_llm.run(prompt, max_tokens=available)
        return result.strip()
