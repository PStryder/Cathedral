# cathedral/StarMirror/StarMirrorGate/__init__.py
import os
import requests
from dotenv import load_dotenv
from pathlib import Path

env_path = Path(__file__).resolve().parents[3] / ".env"
load_dotenv(dotenv_path=env_path)


API_URL = "https://openrouter.ai/api/v1/chat/completions"
API_KEY = os.getenv("OPENROUTER_API_KEY")  # Set this in your .env or system env
DEFAULT_MODEL = "openai/gpt-4o-2024-11-20"
if not API_KEY:
    raise RuntimeError("🛑 OPENROUTER_API_KEY is not set. Ensure your .env file exists and contains the key.")
def transmit(messages, model=DEFAULT_MODEL, temperature=0.7):
    if not isinstance(messages, list) or len(messages) == 0:
        raise ValueError("🛑 Cannot transmit: message list is empty or invalid.")

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }

    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
    }

    print("🧵 Transmit payload messages:")
    for msg in messages:
        print(f" - {msg.get('role', 'unknown')}: {msg.get('content', '[no content]')}")

    try:
        response = requests.post(API_URL, headers=headers, json=payload)
        response.raise_for_status()
    except requests.RequestException as e:
        print("🛑 OpenRouter API call failed.")
        print("Status code:", response.status_code if response else "no response")
        print("Response text:", response.text if response else "no text")
        print("Payload:", payload)
        print("Headers:", headers)
        raise RuntimeError(f"Failed to transmit to LLM: {e}")

    try:
        return response.json()["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as e:
        print("🛑 Malformed response from LLM:")
        print(response.json())
        raise RuntimeError(f"Malformed response structure: {e}")
