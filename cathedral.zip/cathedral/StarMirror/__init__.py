# cathedral/StarMirror/__init__.py
from cathedral.StarMirror.StarMirrorGate import transmit

def reflect(prompt_history, system_prompt=None, temperature=0.7):
    messages = []
    if system_prompt:
        messages.append({ "role": "system", "content": system_prompt })
    messages.extend(prompt_history)  # Should be a list of {role, content} dicts
    return transmit(messages, temperature=temperature)
