import sys
import os

# Add the root project directory to Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from dotenv import load_dotenv
load_dotenv()

from loom import Loom
from cathedral import process_input
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Initialize backend memory manager
loom = Loom()

app = FastAPI()

origins = [
    "http://localhost:5000",
    "http://localhost:8000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request models
class UserInput(BaseModel):
    user_input: str
    thread_uid: str

class ThreadRequest(BaseModel):
    thread_uid: str | None = None
    thread_name: str | None = None  # 👈 Make this optional too!


# Route: process input
@app.post("/interface/")
async def process_input_route(user_input: UserInput):
    print(f"Input received for thread {user_input.thread_uid}: {user_input.user_input}")
    response = process_input(user_input.user_input, thread_uid=user_input.thread_uid)
    return {"response": response}

# Route: create or activate thread
@app.post("/thread/")
async def create_or_activate_thread(request: ThreadRequest):
    if request.thread_uid:
        loom.switch_to_thread(request.thread_uid)
        return {"status": "thread activated", "thread_uid": request.thread_uid}
    else:
        thread_uid = loom.create_new_thread(request.thread_name)
        return {"status": "thread created and activated", "thread_uid": thread_uid}

# Route: explicitly create new thread (optional route)
@app.post("/thread/new/")
async def create_new_thread(request: ThreadRequest):
    thread_uid = loom.create_new_thread(request.thread_name)
    return {"status": "new thread created", "thread_uid": thread_uid}

# Route: list all threads
@app.get("/thread/list/")
async def get_all_threads():
    return {"threads": loom.list_all_threads()}

# Route: get current active thread metadata
@app.get("/thread/active")
def get_active_thread():
    return loom.get_active_thread_metadata()

@app.get("/thread/{thread_uid}/history")
async def get_thread_history(thread_uid: str):
    history = loom.recall(thread_uid)
    return {"history": history}
